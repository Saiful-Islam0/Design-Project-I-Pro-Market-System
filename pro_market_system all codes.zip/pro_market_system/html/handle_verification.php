<?php
require 'db.php';
session_start();

if (!isset($_SESSION['user'])) {
    header('Location: login.html');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $response = $data['response'];
    $receiver_nid = $_SESSION['user']['nid'];
    
    // Update verification message status
    $stmt = $conn->prepare("UPDATE messages SET status = ? WHERE receiver_nid = ? AND status = 'pending'");
    $stmt->bind_param("ss", $response, $receiver_nid);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
    $stmt->close();
    $conn->close();
}
?>
