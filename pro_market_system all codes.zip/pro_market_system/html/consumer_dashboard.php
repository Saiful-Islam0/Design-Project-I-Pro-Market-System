<?php
include 'db.php';

// Fetch product prices
$sql = "SELECT product_name, amount FROM purchases";
$result = $conn->query($sql);
$prices = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $prices[] = $row;
    }
}

echo json_encode($prices);

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
    <div class="price-section">
        <h2>Product Prices</h2>
        <?php if (empty($purchases)) { ?>
            <p>No products available.</p>
        <?php } else { ?>
            <?php foreach ($purchases as $purchase) { ?>
                <div class="product-price">
                    <p>Product: <?php echo $purchase['product_name']; ?></p>
                    <p>Quantity: <?php echo $purchase['quantity']; ?></p>
                    <p>Amount: <?php echo $purchase['amount']; ?></p>
                </div>
            <?php } ?>
        <?php } ?>
    </div>
</body>
</html>
