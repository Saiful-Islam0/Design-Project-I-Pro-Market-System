<?php
include 'db.php';

// Fetch notifications for the farmer
$farmer_id = $_SESSION['user_id']; // Assuming you store the user ID in the session
$sql = "SELECT * FROM notifications WHERE farmer_id = '$farmer_id'";
$result = $conn->query($sql);
$notifications = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
}

echo json_encode($notifications);

$conn->close();
?>
