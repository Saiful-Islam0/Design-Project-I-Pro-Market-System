<?php
include 'db.php';

$notification_id = $_POST['notification_id'];
$action = $_POST['action'];

if ($action === 'accept') {
    $sql = "UPDATE notifications SET status='accepted' WHERE id='$notification_id'";
} else {
    $sql = "UPDATE notifications SET status='declined' WHERE id='$notification_id'";
}

if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

$conn->close();
?>
