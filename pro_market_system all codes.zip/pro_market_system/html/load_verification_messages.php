<?php
include 'db.php';

$role = $_GET['role'];
$user_id = $_SESSION['user_id']; // Assuming you store the user ID in the session

if ($role === 'farmer') {
    $sql = "SELECT * FROM verification_messages WHERE farmer_id = '$user_id'";
} elseif ($role === 'dealer') {
    $sql = "SELECT * FROM verification_messages WHERE dealer_id = '$user_id'";
}
// Add other roles as needed

$result = $conn->query($sql);
$messages = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
}

echo json_encode($messages);

$conn->close();
?>
