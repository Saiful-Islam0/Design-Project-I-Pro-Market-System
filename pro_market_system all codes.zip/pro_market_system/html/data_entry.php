<?php
session_start();
require 'db.php';

$product_name = $_POST['product_name'];
$quantity = $_POST['quantity'];
$amount = $_POST['amount'];
$bought_from_nid = $_POST['bought_from_nid'];
$user_nid = $_SESSION['nid'];

$query = "INSERT INTO purchases (product_name, quantity, amount, bought_from_nid, user_nid) VALUES ('$product_name', '$quantity', '$amount', '$bought_from_nid', '$user_nid')";

if ($conn->query($query) === TRUE) {
    $notification_message = "Product bought from you: $product_name, Quantity: $quantity, Amount: $amount";
    $notification_query = "INSERT INTO notifications (recipient_nid, message, status) VALUES ('$bought_from_nid', '$notification_message', 'pending')";
    $conn->query($notification_query);
    echo "Data saved and verification request sent";
} else {
    echo "Error: " . $conn->error;
}

header("Location: dealer_dashboard.php"); // Redirect back to the dashboard
?>
