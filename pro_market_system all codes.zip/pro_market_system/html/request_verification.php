<?php
require 'db.php';
session_start();

if (!isset($_SESSION['user'])) {
    header('Location: login.html');
    exit();
}

$user_nid = $_SESSION['user']['nid'];
$verification_message = "Verification request from NID: $user_nid";

$stmt = $conn->prepare("INSERT INTO messages (sender_nid, text, status) VALUES (?, ?, 'pending')");
$stmt->bind_param("ss", $user_nid, $verification_message);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
$stmt->close();
$conn->close();
?>
