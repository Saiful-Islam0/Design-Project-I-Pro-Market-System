<?php
require 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $stmt = $conn->prepare("SELECT nid, password FROM users WHERE username = ? AND role = ?");
    $stmt->bind_param("ss", $username, $role);
    $stmt->execute();
    $stmt->bind_result($nid, $hash);
    $stmt->fetch();
    
    if (password_verify($password, $hash)) {
        $_SESSION['user'] = ['nid' => $nid, 'role' => $role];
        switch ($role) {
            case 'farmer':
                header('Location: ../html/farmer_dashboard.html');
                break;
            case 'local_arabdar':
            case 'big_city_dealer':
            case 'retailer':
                header('Location: ../html/other_dashboard.html');
                break;
            case 'consumer':
                header('Location: ../html/consumer_dashboard.html');
                break;
            case 'ministry':
                header('Location: ../html/ministry_dashboard.html');
                break;
        }
        exit();
    } else {
        echo "Invalid login credentials";
    }
    $stmt->close();
}
$conn->close();
?>
