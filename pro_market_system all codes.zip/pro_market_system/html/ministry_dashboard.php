<?php
session_start();
require 'db.php';

$query = "SELECT * FROM complaints";
$result = $conn->query($query);

$complaints = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $complaints[] = $row;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
    <div class="complaint-section">
        <h2>Complaints</h2>
        <?php if (empty($complaints)) { ?>
            <p>No complaints available.</p>
        <?php } else { ?>
            <?php foreach ($complaints as $complaint) { ?>
                <div class="complaint">
                    <p><?php echo $complaint['complaint_text']; ?></p>
                </div>
            <?php } ?>
        <?php } ?>
    </div>
</body>
</html>
