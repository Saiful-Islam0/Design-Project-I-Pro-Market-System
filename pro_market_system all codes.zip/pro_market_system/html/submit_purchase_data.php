<?php
require 'db.php';
session_start();

if (!isset($_SESSION['user'])) {
    header('Location: login.html');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = $_POST['product-name'];
    $quantity = $_POST['quantity'];
    $amount = $_POST['amount'];
    $bought_from = $_POST['bought-from'];
    $user_nid = $_SESSION['user']['nid'];

    $stmt = $conn->prepare("INSERT INTO purchases (product_name, quantity, amount, bought_from, user_nid) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("siiss", $product_name, $quantity, $amount, $bought_from, $user_nid);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
    $stmt->close();
    $conn->close();
}
?>
