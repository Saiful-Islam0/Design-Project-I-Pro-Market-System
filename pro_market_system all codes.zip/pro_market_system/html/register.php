<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nid = $_POST['nid'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role = $_POST['role'];

    $stmt = $conn->prepare("INSERT INTO users (nid, username, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nid, $username, $password, $role);
    
    if ($stmt->execute()) {
        echo "Registration successful";
    } else {
        echo "Registration failed";
    }
    $stmt->close();
}
$conn->close();
?>
