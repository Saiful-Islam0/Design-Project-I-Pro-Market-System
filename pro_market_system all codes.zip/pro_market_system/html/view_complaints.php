<?php
require 'db.php';
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'ministryConsumerRights') {
    header('Location: login.html');
    exit();
}

$result = $conn->query("SELECT * FROM complaints");
$complaints = [];
while ($row = $result->fetch_assoc()) {
    $complaints[] = $row;
}
echo json_encode(['complaints' => $complaints]);
$conn->close();
?>
