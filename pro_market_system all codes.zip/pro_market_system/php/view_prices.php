<?php
require 'db.php';
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'consumer') {
    header('Location: login.html');
    exit();
}

$result = $conn->query("SELECT product_name, amount FROM purchases");
$prices = [];
while ($row = $result->fetch_assoc()) {
    $prices[] = $row;
}
echo json_encode(['prices' => $prices]);
$conn->close();
?>
