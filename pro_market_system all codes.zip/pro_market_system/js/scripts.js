function validateLogin() {
    const role = document.getElementById('role').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (role === "" || username === "" || password === "") {
        alert("All fields are required!");
        return false;
    }
    // Perform further validation or login process here
    return true;
}

function validateRegistration() {
    const role = document.getElementById('role').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (role === "" || username === "" || password === "" || confirmPassword === "") {
        alert("All fields are required!");
        return false;
    }
    
    if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return false;
    }
    // Perform further validation or registration process here
    return true;
}
